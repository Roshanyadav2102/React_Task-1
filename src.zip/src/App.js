import UI from './UI';
import './App.css';

function App() {
  return (
    <div>
      <UI />
    </div>
  );
}

export default App;
